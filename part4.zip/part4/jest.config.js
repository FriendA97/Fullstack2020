module.exports = {
  testEnvironment: "node",
};
